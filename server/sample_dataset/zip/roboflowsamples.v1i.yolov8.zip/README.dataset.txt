# roboflowsamples > 2025-11-26 6:03pm
https://universe.roboflow.com/hi-ms8fn/roboflowsamples-14t6n

Provided by a Roboflow user
License: CC BY 4.0

